<?php 

/**
 * Home template
 *
 */

include("./includes/head.inc"); 

?>


<div class="row">


</div>





<?php
include("./includes/foot.inc"); 

