<?php 

/**
 * Basic Page template
 *
 */

include("./includes/head.inc"); 

?>


<div class="row">

<?php echo $page->body; ?>

</div>





<?php

include("./includes/foot.inc");